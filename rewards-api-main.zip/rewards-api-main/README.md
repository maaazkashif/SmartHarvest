# rewards-api
Backend of the Loyalty &amp; Rewards program of the SmartHarvest Client Engagement Web Portal.

# Running Locally
1. Clone this repo.
```
git clone https://github.com/CPS714-SmartHarvest-Rewards/rewards-api
```
2. Run the Django server.
```
python manage.py runserver
```
