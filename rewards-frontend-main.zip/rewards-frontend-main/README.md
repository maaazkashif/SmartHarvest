# rewards-frontend
Frontend of the Loyalty &amp; Rewards program of SmartHarvest Client Engagement Web Portal.

## Building and Running Locally
1. Clone this repo.
```
git clone https://github.com/CPS714-SmartHarvest-Rewards/rewards-frontend
```
2. Install the dependencies.
```
cd smartharvest
npm install
```
3. Start the app.
```
npm run start
```
4. Open the app in `localhost:3000`.
